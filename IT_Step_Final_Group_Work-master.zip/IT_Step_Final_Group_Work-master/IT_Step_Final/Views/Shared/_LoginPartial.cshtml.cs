using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace IT_Step_Final.Views.Shared
{
    public class _LoginPartialModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
