﻿namespace OnlineStore.Core.Interfaces
{
    public interface IRoomRepository:ICrud<Room,long>
    {
    }
}
