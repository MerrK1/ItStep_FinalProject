﻿using IT_Step_Final;

namespace OnlineStore.Core.Interfaces
{
    public interface IbookingRepository:ICrud<Booking,long> //folof interface segregation principe from solid
    {
    }
}
