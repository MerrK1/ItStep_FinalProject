﻿using IT_Step_Final.Models.Hotel;

namespace OnlineStore.Core.Interfaces
{
    public interface IhotelRepository:ICrud<Hotel,long>
    {

    }
}
