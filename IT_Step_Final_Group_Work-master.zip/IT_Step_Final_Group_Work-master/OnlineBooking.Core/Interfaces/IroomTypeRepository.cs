﻿namespace OnlineStore.Core.Interfaces
{
    public interface IroomTypeRepository : ICrud<RoomType, long>
    {
        //will extend  if other functionalities need
    }
}
